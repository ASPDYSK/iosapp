# 单词检测 iOS App

这是单词检测的原生 SwiftUI iOS App 工程。主界面、系统底部导航、七类检测入口、检测卡片、三条助记、记忆记录和备份入口都由 SwiftUI 原生实现。App 只打包共享词表与助记数据；旧网页界面和 WebView 不再加入构建目标，避免出现两套运行逻辑。

检测顺序与电脑端一致：没测过的单词优先，不认识、记错了、不确定和没记全的单词按权重提高出现顺序，秒杀过的单词降低权重；只有完整测完当前队列时，对应模式的检测遍数才会增加。

检测页点击单词卡片可查看最多三条助记。点击一条助记可选择或取消选择，已有选择时默认只展示选中项；点击铅笔按钮会弹窗编辑助记。选择状态和编辑内容都会进入完整备份。

记录页默认使用整行方块卡片展示单词，点击“批量选择”后才出现方框，可逐个勾选、全选或删除选中项。其余首页和检测页布局保持原来的版本。

底部导航严格使用 Apple 官方 `TabView(selection:)` 和 `Tab` 结构，没有自定义绘制底栏，也没有给自定义胶囊叠加 `glassEffect`。使用 Xcode 26 SDK 构建并运行在 iOS 26 后，浮动 Liquid Glass 底栏、选中态动画、边缘折射和色散全部由系统 `TabView` 自动提供。该实现依据 Apple 的 SwiftUI `TabView` 文档和 WWDC25 “Build a SwiftUI app with the new design” 示例。

学习页的六个记忆判断按钮在 iOS 26 使用官方 `.buttonStyle(.glass)` 和系统 `buttonBorderShape`；iOS 18–25 自动使用系统描边按钮，位置、尺寸和判断逻辑保持一致。

账号页提供“自定义背景”设置，可通过系统 `PhotosPicker` 从相册选择或更换图片、实时调整图片透明度，并可移除恢复默认背景。背景会应用到四个主页面和单词检测页面；图片保存在 App 的 Application Support 目录，透明度保存在 `UserDefaults`，重启 App 后会自动恢复。

账号页还提供“导出 App 数据 TXT”和“选择电脑或手机导出的 TXT”。文件选择兼容常见文本、JSON 和部分文件提供者标记为通用数据的 TXT，并可读取 UTF-8、带 BOM 的文本以及 UTF-16 文本。v2 导出文件是版本化的 UTF-8 JSON 文本，扩展名为 `.txt`，与配套电脑端网页使用完全相同的结构，包含单词、翻译、最多三条助记及选择状态、例句、六种记录次数、最近一次记忆类型、最近检测时间和各模式完成遍数。导入前会自动保存一份当前快照并提示确认，可通过“恢复上一次导入前数据”撤销最近一次完整导入。

在 iPhone 的“文件”、邮件或其他 App 中对 VocabularyCheck v2 TXT 使用“共享/打开方式”，可以选择“单词检测”；首次使用时可能需要在 App 列表末尾点“更多”。App 通过 SwiftUI、App 生命周期和冷启动参数接收文件，兼容 App 已运行和由文件冷启动两种情况。外部文件事件到达时会立即把文件内容复制进内存，避免安全作用域在界面加载前失效。文件校验通过后会立即创建恢复快照并导入，成功后自动进入记录页并显示恢复数量，不再依赖文件选择器关闭后容易被系统吞掉的二次确认弹窗。账号页不再提供复制粘贴框，完整数据统一通过文件导入，真正的数据重复会显示重复单词及其两个位置。账号页改用 UIKit 原生 `UIDocumentPickerViewController(asCopy: true)`：系统先把选中的文件复制给 App，再进行读取，避免第三方文件提供者能勾选却无法读取的问题；选择界面保留圆圈和右上角“打开”，但导入时要求只选择一个文件。账号页会持续显示最近一次导入的进行中、成功或失败状态以及错误原因。文档类型由 iOS 在安装 App 时注册，因此升级这项功能后需要安装 build 6 或更新版本，旧安装不会自动读取工程里的新声明。

录入页和助记编辑页都支持下滑或点击输入区外收起键盘，键盘工具栏也提供“完成”按钮。

导入兼容当前 v2 完整备份、旧 iOS v1 JSON TXT，以及电脑端旧五段式 `单词//翻译//助记//状态//遍数` 文件。旧五段式文件本身没有六类独立次数，因此只能把总次数恢复到文件中记录的最后状态。

## 环境

- macOS
- Xcode 26 或更新版本
- iOS 18 或更新版本；iOS 26 自动启用系统 Liquid Glass 效果

## 运行

1. 用 Xcode 打开 `VocabularyCheck.xcodeproj`。
2. 在项目的 **Signing & Capabilities** 中选择你的 Apple Developer Team。
3. 如有需要，把 Bundle Identifier `com.vipmh.VocabularyCheck` 改成你自己的唯一标识。
4. 选择 iPhone 模拟器或已连接的 iPhone，点击运行。

真机安装时，免费 Apple ID 签名通常需要定期重新签名；发布到 App Store 则需要加入 Apple Developer Program，并在 Xcode 中执行 **Product → Archive**。

## 没有 Mac：免费 7 天自用签名

工程里附带了 `.github/workflows/build-unsigned-ipa.yml`。可以用 GitHub 提供的临时 macOS 云主机编译未签名 IPA，再在 Windows 上用自己的 Apple ID 签名：

1. 把整个工程上传到 GitHub（公开仓库最省事）。
2. 打开仓库的 **Actions → Build unsigned iOS IPA → Run workflow**。
3. 工作流完成后，在页面底部下载 `VocabularyCheck-unsigned-ipa`。
4. 在 Windows 安装 [Sideloadly](https://sideloadly.io/)，连接 iPhone，选择这个 IPA，输入自己的 Apple ID 后点击开始。
5. 在 iPhone 的 **设置 → 通用 → VPN 与设备管理** 中信任自己的开发者证书，然后打开 App。

免费 Apple ID 签名一般有效 7 天，之后在 Sideloadly 中重新点击一次即可续期；通常最多同时保留 3 个自签 App。这个方式完全自用，不需要购买 Apple Developer Program，也不需要 Mac。

## 数据说明

- 单词、三条助记、助记选择、检测记录和检测遍数会保存在设备本地。
- 自定义背景图片和透明度设置也会保存在设备本地。
- 可从账号页导出 v2 完整 TXT 数据备份，并与配套电脑端网页双向导入恢复。
- 首次安装会从工程共享资源载入与电脑端相同的 726 个单词及助记。单词、助记和检测记录使用 Application Support 下的原子 JSON 文件保存，并保留上一版文件；旧 `UserDefaults` 和网页桥接数据会在首次升级时自动迁移。
- 卸载 App 会删除本地数据。

## 工程结构

- `VocabularyCheck/ContentView.swift`：原生 SwiftUI 页面、液态玻璃底栏、检测流程和本地数据模型。
- `VocabularyCheck/WebView.swift`：旧网页容器源码，仅供历史参考，不加入构建目标。
- `VocabularyCheck/Resources/index.html`：旧网页源码，仅供历史参考，不加入 App 资源。
- `VocabularyCheck/Resources/vocab-data.js`：旧网页的初始共享数据。
- `VocabularyCheck/Assets.xcassets`：App 图标。
