import SwiftUI
import UIKit
import WebKit

struct WebView: UIViewRepresentable {
    private static let persistenceHandlerName = "iosPersistence"
    private static let savedStateKey = "VocabularyCheck.savedState"

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.userContentController.add(
            context.coordinator,
            name: Self.persistenceHandlerName
        )

        let savedState = UserDefaults.standard.string(forKey: Self.savedStateKey)
        configuration.userContentController.addUserScript(
            WKUserScript(
                source: bootstrapScript(savedState: savedState),
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = .clear
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.keyboardDismissMode = .interactive
        webView.allowsBackForwardNavigationGestures = false

        guard
            let resourcesURL = Bundle.main.resourceURL,
            let indexURL = Bundle.main.url(
                forResource: "index",
                withExtension: "html"
            )
        else {
            assertionFailure("Bundled web resources are missing")
            return webView
        }

        webView.loadFileURL(indexURL, allowingReadAccessTo: resourcesURL)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.configuration.userContentController.removeScriptMessageHandler(
            forName: persistenceHandlerName
        )
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
    }

    private func bootstrapScript(savedState: String?) -> String {
        guard let savedState, let data = savedState.data(using: .utf8) else {
            return "window.__IOS_SAVED_STATE__ = null;"
        }

        let encodedState = data.base64EncodedString()
        return """
        (() => {
          try {
            const bytes = Uint8Array.from(atob('\(encodedState)'), char => char.charCodeAt(0));
            window.__IOS_SAVED_STATE__ = JSON.parse(new TextDecoder().decode(bytes));
          } catch (_) {
            window.__IOS_SAVED_STATE__ = null;
          }
        })();
        """
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {
            guard
                message.name == WebView.persistenceHandlerName,
                JSONSerialization.isValidJSONObject(message.body),
                let data = try? JSONSerialization.data(withJSONObject: message.body),
                let state = String(data: data, encoding: .utf8)
            else {
                return
            }

            UserDefaults.standard.set(state, forKey: WebView.savedStateKey)
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard
                navigationAction.navigationType == .linkActivated,
                let url = navigationAction.request.url,
                !url.isFileURL
            else {
                decisionHandler(.allow)
                return
            }

            UIApplication.shared.open(url)
            decisionHandler(.cancel)
        }

        func webView(
            _ webView: WKWebView,
            runJavaScriptAlertPanelWithMessage message: String,
            initiatedByFrame frame: WKFrameInfo,
            completionHandler: @escaping () -> Void
        ) {
            guard let presenter = presentingViewController(for: webView) else {
                completionHandler()
                return
            }

            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default) { _ in
                completionHandler()
            })
            presenter.present(alert, animated: true)
        }

        func webView(
            _ webView: WKWebView,
            runJavaScriptConfirmPanelWithMessage message: String,
            initiatedByFrame frame: WKFrameInfo,
            completionHandler: @escaping (Bool) -> Void
        ) {
            guard let presenter = presentingViewController(for: webView) else {
                completionHandler(false)
                return
            }

            let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in
                completionHandler(false)
            })
            alert.addAction(UIAlertAction(title: "确定", style: .destructive) { _ in
                completionHandler(true)
            })
            presenter.present(alert, animated: true)
        }

        func webView(
            _ webView: WKWebView,
            runJavaScriptTextInputPanelWithPrompt prompt: String,
            defaultText: String?,
            initiatedByFrame frame: WKFrameInfo,
            completionHandler: @escaping (String?) -> Void
        ) {
            guard let presenter = presentingViewController(for: webView) else {
                completionHandler(nil)
                return
            }

            let alert = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
            alert.addTextField { textField in
                textField.text = defaultText
            }
            alert.addAction(UIAlertAction(title: "取消", style: .cancel) { _ in
                completionHandler(nil)
            })
            alert.addAction(UIAlertAction(title: "确定", style: .default) { _ in
                completionHandler(alert.textFields?.first?.text)
            })
            presenter.present(alert, animated: true)
        }

        private func presentingViewController(for webView: WKWebView) -> UIViewController? {
            var controller = webView.window?.rootViewController

            while let presentedController = controller?.presentedViewController {
                controller = presentedController
            }

            if let navigationController = controller as? UINavigationController {
                return navigationController.visibleViewController ?? navigationController
            }

            if let tabBarController = controller as? UITabBarController {
                return tabBarController.selectedViewController ?? tabBarController
            }

            return controller
        }
    }
}
