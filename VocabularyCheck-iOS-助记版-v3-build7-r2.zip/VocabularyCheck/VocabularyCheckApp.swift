import SwiftUI
import UIKit

enum VocabularyCheckExternalOpenBridge {
    static let notification = Notification.Name("VocabularyCheckExternalFileOpened")
    struct PendingFile {
        let url: URL
        let data: Data?
    }

    private static var pendingFile: PendingFile?
    private static var lastURL: URL?
    private static var lastReceivedAt = Date.distantPast

    static func receive(_ url: URL) {
        let now = Date()
        guard url != lastURL || now.timeIntervalSince(lastReceivedAt) > 2 else { return }
        let accessing = url.startAccessingSecurityScopedResource()
        let data = try? Data(contentsOf: url)
        if accessing { url.stopAccessingSecurityScopedResource() }
        pendingFile = PendingFile(url: url, data: data)
        lastURL = url
        lastReceivedAt = now
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: notification, object: nil)
        }
    }

    static func takePendingFile() -> PendingFile? {
        defer { pendingFile = nil }
        return pendingFile
    }
}

final class VocabularyCheckAppDelegate: NSObject, UIApplicationDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        if let url = launchOptions?[.url] as? URL {
            VocabularyCheckExternalOpenBridge.receive(url)
        }
        return true
    }

    func application(
        _ application: UIApplication,
        open url: URL,
        options: [UIApplication.OpenURLOptionsKey: Any] = [:]
    ) -> Bool {
        VocabularyCheckExternalOpenBridge.receive(url)
        return true
    }
}

@main
struct VocabularyCheckApp: App {
    @UIApplicationDelegateAdaptor(VocabularyCheckAppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
