import SwiftUI
import UIKit
import Foundation
import Combine
import PhotosUI
import UniformTypeIdentifiers

private extension UTType {
    static let vocabularyCheckBackup = UTType(
        exportedAs: "com.vipmh.vocabularycheck.backup",
        conformingTo: .plainText
    )
}

private enum VocabularyImportReader {
    static let supportedContentTypes: [UTType] = [.vocabularyCheckBackup, .plainText, .text, .json, .data]

    static func read(from url: URL) throws -> String {
        let accessing = url.startAccessingSecurityScopedResource()
        defer { if accessing { url.stopAccessingSecurityScopedResource() } }
        return try decode(Data(contentsOf: url))
    }

    static func decode(_ data: Data) throws -> String {
        if data.starts(with: [0xFF, 0xFE]), let text = String(data: data, encoding: .utf16LittleEndian) {
            return text
        }
        if data.starts(with: [0xFE, 0xFF]), let text = String(data: data, encoding: .utf16BigEndian) {
            return text
        }
        if data.contains(0) {
            for encoding in [String.Encoding.utf16, .utf16LittleEndian, .utf16BigEndian] {
                if let text = String(data: data, encoding: encoding) { return text }
            }
        }
        let encodings: [String.Encoding] = [.utf8, .utf16, .utf16LittleEndian, .utf16BigEndian]
        for encoding in encodings {
            if let text = String(data: data, encoding: encoding) {
                return text
            }
        }
        throw VocabularyBackupError.invalidText
    }
}

private struct VocabularyDocumentPicker: UIViewControllerRepresentable {
    let onPick: ([URL]) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: VocabularyImportReader.supportedContentTypes,
            asCopy: true
        )
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) { }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: ([URL]) -> Void
        let onCancel: () -> Void

        init(onPick: @escaping ([URL]) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}

private struct MnemonicItem: Identifiable, Codable, Hashable {
    var id: String
    var text: String
    var selected: Bool = false
}

private struct VocabularyWord: Identifiable, Codable, Hashable {
    let id: UUID
    var word: String
    var translation: String
    var mnemonics: [MnemonicItem]
    var example: String

    init(id: UUID = UUID(), word: String, translation: String, mnemonics: [MnemonicItem] = [], example: String = "") {
        self.id = id
        self.word = word
        self.translation = translation
        self.mnemonics = mnemonics
        self.example = example
    }

    init(id: UUID = UUID(), word: String, translation: String, mnemonic: String, example: String = "") {
        self.init(id: id, word: word, translation: translation,
                  mnemonics: mnemonic.isEmpty ? [] : [MnemonicItem(id: "1", text: mnemonic)], example: example)
    }

    var mnemonic: String { mnemonics.map(\.text).joined(separator: "|") }

    private enum CodingKeys: String, CodingKey { case id, word, translation, mnemonics, mnemonic, example }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        word = try container.decode(String.self, forKey: .word)
        translation = try container.decodeIfPresent(String.self, forKey: .translation) ?? ""
        example = try container.decodeIfPresent(String.self, forKey: .example) ?? ""
        if let items = try container.decodeIfPresent([MnemonicItem].self, forKey: .mnemonics) {
            mnemonics = items
        } else {
            let oldMnemonic = try container.decodeIfPresent(String.self, forKey: .mnemonic) ?? ""
            mnemonics = oldMnemonic.isEmpty ? [] : [MnemonicItem(id: "1", text: oldMnemonic)]
        }
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(word, forKey: .word)
        try container.encode(translation, forKey: .translation)
        try container.encode(mnemonics, forKey: .mnemonics)
        try container.encode(example, forKey: .example)
    }
}

private enum MemoryCategory: String, CaseIterable, Codable, Identifiable {
    case instant, know, partial, unsure, misremember, unknown
    var id: String { rawValue }
    var title: String {
        switch self { case .instant: return "秒杀"; case .know: return "认识"; case .partial: return "没记全"; case .unsure: return "不确定"; case .misremember: return "记错了"; case .unknown: return "不认识" }
    }
    var icon: String {
        switch self { case .instant: return "bolt"; case .know: return "checkmark.circle"; case .partial: return "circle.dashed"; case .unsure: return "questionmark.circle"; case .misremember: return "arrow.counterclockwise"; case .unknown: return "xmark.circle" }
    }
    var tint: Color {
        switch self { case .instant: return .blue; case .know: return .green; case .partial: return .teal; case .unsure: return .orange; case .misremember: return .pink; case .unknown: return .red }
    }
}

private enum PracticeMode: Hashable {
    case all
    case untested
    case category(MemoryCategory)

    var key: String {
        switch self { case .all: return "all"; case .untested: return "untested"; case .category(let category): return category.rawValue }
    }
    var title: String {
        switch self { case .all: return "全部单词"; case .untested: return "没测过"; case .category(let category): return "类目「\(category.title)」" }
    }
}

private struct MemoryRecord: Codable, Hashable {
    var counts: [MemoryCategory: Int] = [:]
    var lastCategory: MemoryCategory?
    var lastTestedAt: Date?
    var total: Int { counts.values.reduce(0, +) }
    var mastery: Double {
        guard total > 0 else { return 0 }
        let score = Double(counts[.instant, default: 0] + counts[.know, default: 0]) + Double(counts[.partial, default: 0]) * 0.7 + Double(counts[.unsure, default: 0]) * 0.5
        return score / Double(total)
    }
}

private enum AppTab: String, CaseIterable, Identifiable, Hashable {
    case practice, input, records, account
    var id: String { rawValue }
    var title: String { switch self { case .practice: return "练习"; case .input: return "录入"; case .records: return "记录"; case .account: return "账号" } }
    var icon: String { switch self { case .practice: return "book.closed"; case .input: return "square.and.pencil"; case .records: return "checklist"; case .account: return "person.crop.circle" } }
}

private enum NativeVocabularyStore {
    static let wordsKey = "VocabularyCheck.native.words"
    static let recordsKey = "VocabularyCheck.native.records"
    static let roundsKey = "VocabularyCheck.native.rounds"
    static let legacyStateKey = "VocabularyCheck.savedState"
    static let initialWords = MnemonicLibrary.initialWords
    private static let wordsFilename = "words-v2.json"
    private static let recordsFilename = "records-v2.json"
    private static let roundsFilename = "rounds-v2.json"

    private static var storageFolder: URL? {
        guard let applicationSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let folder = applicationSupport.appendingPathComponent("VocabularyCheck", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: nil)
            return folder
        } catch {
            print("VocabularyCheck storage directory error: \(error)")
            return nil
        }
    }

    private static func fileURL(_ filename: String) -> URL? { storageFolder?.appendingPathComponent(filename) }
    private static func backupURL(_ filename: String) -> URL? { fileURL(filename)?.appendingPathExtension("backup") }
    private static func hasFile(_ filename: String) -> Bool {
        [fileURL(filename), backupURL(filename)].compactMap { $0 }.contains { FileManager.default.fileExists(atPath: $0.path) }
    }
    private static func read<T: Decodable>(_ filename: String, as type: T.Type) -> T? {
        for url in [fileURL(filename), backupURL(filename)].compactMap({ $0 }) {
            guard let data = try? Data(contentsOf: url) else { continue }
            if let value = try? JSONDecoder().decode(type, from: data) { return value }
        }
        return nil
    }
    @discardableResult
    private static func write<T: Encodable>(_ value: T, to filename: String) -> Bool {
        guard let url = fileURL(filename), let backup = backupURL(filename) else { return false }
        do {
            let data = try JSONEncoder().encode(value)
            if FileManager.default.fileExists(atPath: url.path) {
                if FileManager.default.fileExists(atPath: backup.path) { try FileManager.default.removeItem(at: backup) }
                try FileManager.default.copyItem(at: url, to: backup)
            }
            try data.write(to: url, options: .atomic)
            return true
        } catch {
            print("VocabularyCheck write error for \(filename): \(error)")
            return false
        }
    }

    static func loadWords() -> [VocabularyWord] {
        if hasFile(wordsFilename) { return MnemonicLibrary.enrich(read(wordsFilename, as: [VocabularyWord].self) ?? []) }
        if let data = UserDefaults.standard.data(forKey: wordsKey), let words = try? JSONDecoder().decode([VocabularyWord].self, from: data) {
            write(words, to: wordsFilename)
            return MnemonicLibrary.enrich(words)
        }
        if let legacy = loadLegacyState(), let legacyWords = legacy.words, !legacyWords.isEmpty {
            let words = legacyWords.map { VocabularyWord(word: $0.w, translation: $0.t) }
            write(words, to: wordsFilename)
            return MnemonicLibrary.enrich(words)
        }
        write(initialWords, to: wordsFilename)
        return initialWords
    }
    static func loadRounds() -> [String: Int] {
        if hasFile(roundsFilename) { return read(roundsFilename, as: [String: Int].self) ?? [:] }
        if let data = UserDefaults.standard.data(forKey: roundsKey), let rounds = try? JSONDecoder().decode([String: Int].self, from: data) {
            write(rounds, to: roundsFilename)
            return rounds
        }
        return [:]
    }
    static func loadRecords() -> [String: MemoryRecord] {
        if hasFile(recordsFilename) { return read(recordsFilename, as: [String: MemoryRecord].self) ?? [:] }
        if let data = UserDefaults.standard.data(forKey: recordsKey), let records = try? JSONDecoder().decode([String: MemoryRecord].self, from: data) {
            write(records, to: recordsFilename)
            return records
        }
        guard let legacyRecords = loadLegacyState()?.records else { return [:] }
        let records = legacyRecords.reduce(into: [String: MemoryRecord]()) { result, item in
            var record = MemoryRecord()
            record.counts[.instant] = item.value.instant ?? 0
            record.counts[.know] = item.value.know ?? 0
            record.counts[.partial] = item.value.partial ?? 0
            record.counts[.unsure] = item.value.unsure ?? 0
            record.counts[.misremember] = item.value.misremember ?? 0
            record.counts[.unknown] = item.value.unknown ?? 0
            record.lastCategory = item.value.last.flatMap(MemoryCategory.init(rawValue:))
            if let milliseconds = item.value.time, milliseconds > 0 { record.lastTestedAt = Date(timeIntervalSince1970: Double(milliseconds) / 1000) }
            result[item.key] = record
        }
        write(records, to: recordsFilename)
        return records
    }
    @discardableResult
    static func save(words: [VocabularyWord], records: [String: MemoryRecord], rounds: [String: Int] = [:]) -> Bool {
        let wordsSaved = write(words, to: wordsFilename)
        return saveProgress(records: records, rounds: rounds) && wordsSaved
    }
    @discardableResult
    static func saveProgress(records: [String: MemoryRecord], rounds: [String: Int]) -> Bool {
        let recordsSaved = write(records, to: recordsFilename)
        let roundsSaved = write(rounds, to: roundsFilename)
        return recordsSaved && roundsSaved
    }

    private static func loadLegacyState() -> LegacyState? {
        guard let raw = UserDefaults.standard.string(forKey: legacyStateKey), let data = raw.data(using: .utf8) else { return nil }
        return try? JSONDecoder().decode(LegacyState.self, from: data)
    }
}

private struct BundledMnemonicGroup: Decodable {
    let word: String
    let items: [BundledMnemonicItem]
}

private struct BundledMnemonicItem: Decodable {
    let id: String
    let text: String
}

private struct BundledVocabularyFile: Decodable {
    let words: [BundledVocabularyWord]
}

private struct BundledVocabularyWord: Decodable {
    let w: String
    let t: String
}

private enum MnemonicLibrary {
    private static let groups: [String: [MnemonicItem]] = {
        guard let url = Bundle.main.url(forResource: "mnemonics_data", withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8),
              let start = source.firstIndex(of: "["), let end = source.lastIndex(of: "]"), start <= end,
              let data = String(source[start...end]).data(using: .utf8),
              let decoded = try? JSONDecoder().decode([BundledMnemonicGroup].self, from: data) else { return [:] }
        return Dictionary(uniqueKeysWithValues: decoded.map { group in
            (group.word, group.items.map { MnemonicItem(id: $0.id, text: $0.text) })
        })
    }()

    static let initialWords: [VocabularyWord] = {
        guard let url = Bundle.main.url(forResource: "vocab-data", withExtension: "js"),
              let source = try? String(contentsOf: url, encoding: .utf8),
              let start = source.firstIndex(of: "{"), let end = source.lastIndex(of: "}"), start <= end,
              let data = String(source[start...end]).data(using: .utf8),
              let payload = try? JSONDecoder().decode(BundledVocabularyFile.self, from: data),
              !payload.words.isEmpty else {
            return [VocabularyWord(word: "example", translation: "n. 示例", mnemonics: [MnemonicItem(id: "1", text: "示例助记")])]
        }
        return enrich(payload.words.map { VocabularyWord(word: $0.w, translation: $0.t) })
    }()

    static func enrich(_ words: [VocabularyWord]) -> [VocabularyWord] {
        words.map { word in
            guard let bundled = groups[word.word], !bundled.isEmpty else { return word }
            var updated = word
            if updated.mnemonics.isEmpty {
                updated.mnemonics = bundled
            } else {
                let existingTexts = Set(updated.mnemonics.map(\.text))
                updated.mnemonics.append(contentsOf: bundled.filter { !existingTexts.contains($0.text) })
            }
            updated.mnemonics = Array(updated.mnemonics.prefix(3))
            return updated
        }
    }
}

private enum NativeBackgroundStore {
    private static var imageURL: URL? {
        guard let applicationSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let folder = applicationSupport.appendingPathComponent("VocabularyCheck", isDirectory: true)
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: nil)
        return folder.appendingPathComponent("custom-background")
    }

    static func load() -> UIImage? {
        guard let imageURL, let data = try? Data(contentsOf: imageURL) else { return nil }
        return UIImage(data: data)
    }

    static func save(_ data: Data) -> UIImage? {
        guard let image = UIImage(data: data), let imageURL else { return nil }
        do {
            try data.write(to: imageURL, options: .atomic)
            return image
        } catch {
            return nil
        }
    }

    static func remove() {
        guard let imageURL, FileManager.default.fileExists(atPath: imageURL.path) else { return }
        try? FileManager.default.removeItem(at: imageURL)
    }
}

private enum NativeBackupSnapshotStore {
    private static var snapshotURL: URL? {
        guard let applicationSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        let folder = applicationSupport.appendingPathComponent("VocabularyCheck", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: nil)
            return folder.appendingPathComponent("pre-import-snapshot-v2.txt")
        } catch {
            print("VocabularyCheck snapshot directory error: \(error)")
            return nil
        }
    }

    static var exists: Bool { snapshotURL.map { FileManager.default.fileExists(atPath: $0.path) } ?? false }

    @discardableResult
    static func save(_ text: String) -> Bool {
        guard let snapshotURL else { return false }
        do {
            try Data(text.utf8).write(to: snapshotURL, options: .atomic)
            return true
        } catch {
            print("VocabularyCheck snapshot write error: \(error)")
            return false
        }
    }

    static func load() throws -> String {
        guard let snapshotURL else { throw VocabularyBackupError.invalidText }
        return try String(contentsOf: snapshotURL, encoding: .utf8)
    }
}

private struct VocabularyTXTDocument: FileDocument {
    static var readableContentTypes: [UTType] { VocabularyImportReader.supportedContentTypes }
    var text: String

    init(text: String = "") {
        self.text = text
    }

    init(configuration: ReadConfiguration) throws {
        guard let data = configuration.file.regularFileContents else {
            throw VocabularyBackupError.invalidText
        }
        self.text = try VocabularyImportReader.decode(data)
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: Data(text.utf8))
    }
}

private struct VocabularyBackupFile: Codable {
    let format: String
    let version: Int
    let exportedAt: String
    let rounds: [String: Int]
    let words: [VocabularyBackupWord]
}

private struct VocabularyBackupWord: Codable {
    let id: UUID
    let word: String
    let translation: String
    let mnemonics: [MnemonicItem]
    let example: String
    let memory: VocabularyBackupMemory
}

private struct VocabularyBackupMemory: Codable {
    let instant: Int
    let know: Int
    let partial: Int
    let unsure: Int
    let misremember: Int
    let unknown: Int
    let total: Int
    let lastCategory: MemoryCategory?
    let lastTestedAt: String?

    init(record: MemoryRecord?) {
        instant = record?.counts[.instant] ?? 0
        know = record?.counts[.know] ?? 0
        partial = record?.counts[.partial] ?? 0
        unsure = record?.counts[.unsure] ?? 0
        misremember = record?.counts[.misremember] ?? 0
        unknown = record?.counts[.unknown] ?? 0
        total = instant + know + partial + unsure + misremember + unknown
        lastCategory = record?.lastCategory
        lastTestedAt = record?.lastTestedAt.map { ISO8601DateFormatter().string(from: $0) }
    }

    var record: MemoryRecord {
        MemoryRecord(
            counts: [
                .instant: instant,
                .know: know,
                .partial: partial,
                .unsure: unsure,
                .misremember: misremember,
                .unknown: unknown
            ],
            lastCategory: lastCategory,
            lastTestedAt: lastTestedAt.flatMap { ISO8601DateFormatter().date(from: $0) }
        )
    }
}

private struct VocabularyBackupFileV1: Codable {
    let format: String
    let version: Int
    let words: [VocabularyBackupWordV1]
}

private struct VocabularyBackupWordV1: Codable {
    let id: UUID
    let word: String
    let translation: String
    let mnemonic: String
    let example: String
    let memory: VocabularyBackupMemoryV1
}

private struct VocabularyBackupMemoryV1: Codable {
    let instant: Int
    let know: Int
    let partial: Int
    let unsure: Int
    let misremember: Int
    let unknown: Int
    let lastCategory: MemoryCategory?

    var record: MemoryRecord {
        MemoryRecord(counts: [.instant: instant, .know: know, .partial: partial, .unsure: unsure, .misremember: misremember, .unknown: unknown], lastCategory: lastCategory)
    }
}

private enum VocabularyBackupError: LocalizedError {
    case invalidText
    case wrongFormat
    case unsupportedVersion(Int)
    case emptyBackup
    case invalidWord
    case duplicateWord(String, Int, Int)
    case snapshotSaveFailed

    var errorDescription: String? {
        switch self {
        case .invalidText: return "无法读取这个 TXT 文件。"
        case .wrongFormat: return "这不是 VocabularyCheck 导出的数据文件。"
        case .unsupportedVersion(let version): return "暂不支持版本 \(version) 的数据文件。"
        case .emptyBackup: return "数据文件中没有单词。"
        case .invalidWord: return "数据文件中包含空白单词。"
        case .duplicateWord(let word, let first, let duplicate): return "第 \(first) 项和第 \(duplicate) 项是重复单词：\(word)。"
        case .snapshotSaveFailed: return "无法创建导入前快照，已取消导入以保护当前数据。"
        }
    }
}

private enum VocabularyBackupCodec {
    static let format = "VocabularyCheck"
    static let version = 2

    static func encode(words: [VocabularyWord], records: [String: MemoryRecord], rounds: [String: Int]) throws -> String {
        let payload = VocabularyBackupFile(
            format: format,
            version: version,
            exportedAt: ISO8601DateFormatter().string(from: Date()),
            rounds: rounds,
            words: words.map { word in
                VocabularyBackupWord(
                    id: word.id,
                    word: word.word,
                    translation: word.translation,
                    mnemonics: word.mnemonics,
                    example: word.example,
                    memory: VocabularyBackupMemory(record: records[word.word])
                )
            }
        )
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        let data = try encoder.encode(payload)
        guard let text = String(data: data, encoding: .utf8) else { throw VocabularyBackupError.invalidText }
        return text
    }

    static func decode(_ text: String) throws -> (words: [VocabularyWord], records: [String: MemoryRecord], rounds: [String: Int]) {
        let cleanText = normalized(text)
        guard !cleanText.isEmpty, let data = cleanText.data(using: .utf8) else { throw VocabularyBackupError.invalidText }
        if let header = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let backupVersion = header["version"] as? Int {
            if backupVersion == 2 {
                guard let payload = try? JSONDecoder().decode(VocabularyBackupFile.self, from: data) else { throw VocabularyBackupError.wrongFormat }
                guard payload.format == format else { throw VocabularyBackupError.wrongFormat }
                let records = payload.words.reduce(into: [String: MemoryRecord]()) { $0[$1.word] = $1.memory.record }
                return try validated(words: payload.words.map { VocabularyWord(id: $0.id, word: $0.word, translation: $0.translation, mnemonics: $0.mnemonics, example: $0.example) }, records: records, rounds: payload.rounds)
            }
            if backupVersion == 1 {
                guard let payload = try? JSONDecoder().decode(VocabularyBackupFileV1.self, from: data) else { throw VocabularyBackupError.wrongFormat }
                guard payload.format == format else { throw VocabularyBackupError.wrongFormat }
                let words = payload.words.map { VocabularyWord(id: $0.id, word: $0.word, translation: $0.translation, mnemonic: $0.mnemonic, example: $0.example) }
                let records = payload.words.reduce(into: [String: MemoryRecord]()) { $0[$1.word] = $1.memory.record }
                return try validated(words: words, records: records, rounds: [:])
            }
            throw VocabularyBackupError.unsupportedVersion(backupVersion)
        }
        return try decodeLegacyLines(cleanText)
    }

    private static func validated(words: [VocabularyWord], records: [String: MemoryRecord], rounds: [String: Int]) throws -> (words: [VocabularyWord], records: [String: MemoryRecord], rounds: [String: Int]) {
        guard !words.isEmpty else { throw VocabularyBackupError.emptyBackup }
        var firstPositions: [String: Int] = [:]
        var importedWords: [VocabularyWord] = []
        var importedRecords: [String: MemoryRecord] = [:]
        for (index, item) in words.enumerated() {
            let cleanWord = item.word.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleanWord.isEmpty else { throw VocabularyBackupError.invalidWord }
            if let firstPosition = firstPositions[cleanWord] {
                throw VocabularyBackupError.duplicateWord(cleanWord, firstPosition, index + 1)
            }
            firstPositions[cleanWord] = index + 1
            importedWords.append(VocabularyWord(id: item.id, word: cleanWord, translation: item.translation, mnemonics: Array(item.mnemonics.prefix(3)), example: item.example))
            if let record = records[item.word] { importedRecords[cleanWord] = record }
        }
        return (MnemonicLibrary.enrich(importedWords), importedRecords, rounds)
    }

    private static func decodeLegacyLines(_ text: String) throws -> (words: [VocabularyWord], records: [String: MemoryRecord], rounds: [String: Int]) {
        let titleMap = Dictionary(uniqueKeysWithValues: MemoryCategory.allCases.map { ($0.title, $0) })
        var words: [VocabularyWord] = []
        var records: [String: MemoryRecord] = [:]
        for rawLine in text.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !line.isEmpty else { continue }
            let fields = line.components(separatedBy: "//").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            guard let rawWord = fields.first, !rawWord.isEmpty else { continue }
            let translation = fields.count > 1 ? fields[1] : ""
            let mnemonicText = fields.count > 2 ? fields[2] : ""
            let mnemonics = mnemonicText.split(separator: "|", omittingEmptySubsequences: true).prefix(3).enumerated().map { MnemonicItem(id: String($0.offset + 1), text: String($0.element).trimmingCharacters(in: .whitespacesAndNewlines)) }
            words.append(VocabularyWord(word: rawWord, translation: translation, mnemonics: mnemonics))
            if fields.count > 4, let count = Int(fields[4]), count > 0 {
                let category = MemoryCategory(rawValue: fields[3]) ?? titleMap[fields[3]]
                if let category { records[rawWord] = MemoryRecord(counts: [category: count], lastCategory: category) }
            }
        }
        return try validated(words: words, records: records, rounds: [:])
    }

    static func isVersionedBackup(_ text: String) -> Bool {
        let cleanText = normalized(text)
        guard let data = cleanText.data(using: .utf8),
              let header = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return false }
        return header["format"] as? String == format && header["version"] as? Int != nil
    }

    static func normalized(_ text: String) -> String {
        let trimSet = CharacterSet.whitespacesAndNewlines.union(CharacterSet(charactersIn: "\u{feff}"))
        let cleanText = text.trimmingCharacters(in: trimSet)
        guard cleanText.first == "{" else { return cleanText }

        var remaining = cleanText[...]
        var objects: [String] = []
        while !remaining.isEmpty {
            guard let endIndex = endOfFirstJSONObject(in: remaining) else { return cleanText }
            objects.append(String(remaining[..<endIndex]))
            remaining = remaining[endIndex...].drop(while: { $0.isWhitespace })
        }
        guard objects.count > 1, Set(objects).count == 1 else { return cleanText }
        return objects[0]
    }

    private static func endOfFirstJSONObject(in text: Substring) -> String.Index? {
        var depth = 0
        var isInsideString = false
        var isEscaped = false
        for index in text.indices {
            let character = text[index]
            if isInsideString {
                if isEscaped {
                    isEscaped = false
                } else if character == "\\" {
                    isEscaped = true
                } else if character == "\"" {
                    isInsideString = false
                }
                continue
            }
            if character == "\"" {
                isInsideString = true
            } else if character == "{" {
                depth += 1
            } else if character == "}" {
                depth -= 1
                if depth == 0 { return text.index(after: index) }
            }
        }
        return nil
    }
}

private struct LegacyState: Codable {
    var words: [LegacyWord]?
    var records: [String: LegacyRecord]?
}

private struct LegacyWord: Codable {
    var w: String
    var t: String
}

private struct LegacyRecord: Codable {
    var instant: Int?
    var know: Int?
    var partial: Int?
    var unsure: Int?
    var misremember: Int?
    var unknown: Int?
    var last: String?
    var time: Int?
}

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedTab: AppTab = .practice
    @State private var words = NativeVocabularyStore.loadWords()
    @State private var records = NativeVocabularyStore.loadRecords()
    @State private var rounds = NativeVocabularyStore.loadRounds()
    @State private var inputText = ""
    @State private var practiceSession: PracticeSession?
    @State private var showBackup = false
    @State private var hasImportSnapshot = NativeBackupSnapshotStore.exists
    @State private var showStorageError = false
    @State private var backgroundImage = NativeBackgroundStore.load()
    @State private var externalImportMessage = ""
    @State private var showExternalImportResult = false
    @AppStorage("VocabularyCheck.lastImportStatus") private var importStatus = "尚未进行文件导入。"
    @AppStorage("VocabularyCheck.backgroundTransparency") private var backgroundTransparency = 0.65
    @AppStorage("VocabularyCheck.practiceWordCardOpacity") private var practiceWordCardOpacity = 0.92
    @AppStorage("VocabularyCheck.practiceTranslationOpacity") private var practiceTranslationOpacity = 0.90
    @AppStorage("VocabularyCheck.practiceAnswerPanelOpacity") private var practiceAnswerPanelOpacity = 0.88
    @AppStorage("VocabularyCheck.practiceWordCardHeightRatio") private var practiceWordCardHeightRatio = 0.48
    @AppStorage("VocabularyCheck.practiceAnswerPanelHeightRatio") private var practiceAnswerPanelHeightRatio = 0.28

    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()

            if let backgroundImage {
                GeometryReader { proxy in
                    Image(uiImage: backgroundImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(1 - backgroundTransparency)
                }
                .ignoresSafeArea()
            }

            // Apple SwiftUI TabView pattern:
            // https://developer.apple.com/documentation/swiftui/tabview
            TabView(selection: $selectedTab) {
                Tab("练习", systemImage: "book.closed", value: .practice) {
                    PracticeHomeView(words: words, records: records, rounds: rounds, start: beginPractice)
                }

                Tab("录入", systemImage: "square.and.pencil", value: .input) {
                    InputView(inputText: $inputText, savedCount: words.count, save: saveInput, start: { beginPractice(mode: .all) })
                }

                Tab("记录", systemImage: "checklist", value: .records) {
                    RecordsView(words: words, records: records, delete: deleteWords, clearRecords: clearRecords)
                }

                Tab("账号", systemImage: "person.crop.circle", value: .account) {
                    AccountView(
                        backgroundImage: backgroundImage,
                        backgroundTransparency: $backgroundTransparency,
                        setBackground: setBackground,
                        removeBackground: removeBackground,
                        makeExportText: makeExportText,
                        importText: importText,
                        importStatus: $importStatus,
                        importCompleted: { count in
                            selectedTab = .records
                            presentExternalImportResult("导入完成，共恢复 \(count) 个单词及其记忆记录。")
                        },
                        restoreSnapshot: restoreSnapshot,
                        hasImportSnapshot: hasImportSnapshot,
                        showBackup: { showBackup = true },
                        practiceWordCardOpacity: $practiceWordCardOpacity,
                        practiceTranslationOpacity: $practiceTranslationOpacity,
                        practiceAnswerPanelOpacity: $practiceAnswerPanelOpacity,
                        practiceWordCardHeightRatio: $practiceWordCardHeightRatio,
                        practiceAnswerPanelHeightRatio: $practiceAnswerPanelHeightRatio
                    )
                }
            }
        }
        .fullScreenCover(item: $practiceSession) { session in
            PracticeView(
                words: $words,
                queueIDs: session.wordIDs,
                backgroundImage: backgroundImage,
                backgroundTransparency: backgroundTransparency,
                wordCardOpacity: practiceWordCardOpacity,
                translationOpacity: practiceTranslationOpacity,
                answerPanelOpacity: practiceAnswerPanelOpacity,
                wordCardHeightRatio: practiceWordCardHeightRatio,
                answerPanelHeightRatio: practiceAnswerPanelHeightRatio,
                records: $records,
                rounds: $rounds,
                modeKey: session.modeKey,
                modeTitle: session.title,
                save: persist,
                saveProgress: persistProgress,
                finish: { practiceSession = nil; selectedTab = .records }
            )
        }
        .sheet(isPresented: $showBackup) { BackupView(words: words, records: records) }
        .onAppear {
            inputText = inputLines
            reconcileRecords()
            receivePendingExternalFile()
        }
        .onOpenURL { VocabularyCheckExternalOpenBridge.receive($0) }
        .onReceive(NotificationCenter.default.publisher(for: VocabularyCheckExternalOpenBridge.notification)) { _ in
            receivePendingExternalFile()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { receivePendingExternalFile() }
        }
        .alert("外部文件导入", isPresented: $showExternalImportResult) {
            Button("好", role: .cancel) { }
        } message: {
            Text(externalImportMessage)
        }
        .alert("保存失败", isPresented: $showStorageError) {
            Button("好", role: .cancel) { }
        } message: {
            Text("无法写入本机数据，请先导出当前数据并检查设备剩余空间。")
        }
    }

    private var inputLines: String {
        words.map { "\($0.word)//\($0.translation)//\($0.mnemonics.map(\.text).joined(separator: "|"))" }.joined(separator: "\n")
    }
    private func reconcileRecords() {
        let currentWords = Set(words.map(\.word))
        let cleaned = records.filter { currentWords.contains($0.key) }
        if cleaned.count != records.count {
            records = cleaned
            persistProgress()
        }
    }
    private func beginPractice(mode: PracticeMode) {
        let scope: [VocabularyWord]
        switch mode {
        case .all: scope = words
        case .untested: scope = words.filter { (records[$0.word]?.total ?? 0) == 0 }
        case .category(let category): scope = words.filter { records[$0.word]?.lastCategory == category }
        }
        guard !scope.isEmpty else { return }
        practiceSession = PracticeSession(wordIDs: weightedOrder(scope).map(\.id), modeKey: mode.key, title: mode.title)
    }
    private func weightedOrder(_ source: [VocabularyWord]) -> [VocabularyWord] {
        var bag = source.map { word -> (VocabularyWord, Double) in
            guard let record = records[word.word], record.total > 0 else { return (word, 4) }
            if record.lastCategory == .instant { return (word, 0.2) }
            let weight = 1
                + Double(record.counts[.unknown, default: 0]) * 5
                + Double(record.counts[.misremember, default: 0]) * 4
                + Double(record.counts[.unsure, default: 0]) * 3
                + Double(record.counts[.partial, default: 0]) * 2
                + Double(record.counts[.instant, default: 0]) * 0.3
            return (word, weight)
        }
        var result: [VocabularyWord] = []
        while !bag.isEmpty {
            var choice = Double.random(in: 0..<bag.reduce(0) { $0 + $1.1 })
            var selectedIndex = bag.index(before: bag.endIndex)
            for index in bag.indices {
                choice -= bag[index].1
                if choice <= 0 { selectedIndex = index; break }
            }
            result.append(bag.remove(at: selectedIndex).0)
        }
        return result
    }
    private func saveInput() {
        var seen = Set<String>()
        let parsed = inputText.split(separator: "\n", omittingEmptySubsequences: true).compactMap { parse(line: String($0)) }.filter { seen.insert($0.word).inserted }
        guard !parsed.isEmpty else { return }
        words = parsed
        let currentWords = Set(words.map(\.word))
        records = records.filter { currentWords.contains($0.key) }
        persist()
    }
    private func parse(line: String) -> VocabularyWord? {
        let parts = line.components(separatedBy: "//")
        var rawWord = parts.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        var translation = ""
        var mnemonicText = ""
        if parts.count >= 3 {
            translation = parts[1].trimmingCharacters(in: .whitespacesAndNewlines)
            mnemonicText = parts[2].trimmingCharacters(in: .whitespacesAndNewlines)
        } else if parts.count == 2 {
            let legacy = parts[1].components(separatedBy: "\\")
            translation = legacy.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            mnemonicText = legacy.dropFirst().joined(separator: "\\").trimmingCharacters(in: .whitespacesAndNewlines)
        } else {
            let separators = CharacterSet(charactersIn: ",，\t")
            let simple = line.components(separatedBy: separators).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            rawWord = simple.first ?? ""
            translation = simple.dropFirst().joined(separator: " ")
        }
        guard !rawWord.isEmpty else { return nil }
        let old = words.first(where: { $0.word == rawWord })
        let oldSelection = Set(old?.mnemonics.filter(\.selected).map(\.text) ?? [])
        let mnemonics = mnemonicText.split(separator: "|", omittingEmptySubsequences: true).prefix(3).enumerated().map {
            let text = String($0.element).trimmingCharacters(in: .whitespacesAndNewlines)
            return MnemonicItem(id: String($0.offset + 1), text: text, selected: oldSelection.contains(text))
        }
        return VocabularyWord(id: old?.id ?? UUID(), word: rawWord, translation: translation, mnemonics: mnemonics, example: old?.example ?? "")
    }
    private func deleteWords(_ ids: Set<UUID>) {
        let removed = words.filter { ids.contains($0.id) }.map(\.word)
        words.removeAll { ids.contains($0.id) }
        removed.forEach { records.removeValue(forKey: $0) }
        persist()
    }
    private func clearRecords() {
        records = [:]
        rounds = [:]
        persistProgress()
    }
    private func setBackground(_ data: Data) {
        if let image = NativeBackgroundStore.save(data) {
            backgroundImage = image
        }
    }
    private func removeBackground() {
        NativeBackgroundStore.remove()
        backgroundImage = nil
    }
    private func makeExportText() throws -> String {
        try VocabularyBackupCodec.encode(words: words, records: records, rounds: rounds)
    }
    private func importText(_ text: String) throws -> Int {
        let imported = try VocabularyBackupCodec.decode(text)
        let snapshot = try VocabularyBackupCodec.encode(words: words, records: records, rounds: rounds)
        guard NativeBackupSnapshotStore.save(snapshot) else { throw VocabularyBackupError.snapshotSaveFailed }
        hasImportSnapshot = true
        words = imported.words
        records = imported.records
        rounds = imported.rounds
        inputText = inputLines
        persist()
        return words.count
    }
    private func restoreSnapshot() throws -> Int {
        let restored = try VocabularyBackupCodec.decode(NativeBackupSnapshotStore.load())
        words = restored.words
        records = restored.records
        rounds = restored.rounds
        inputText = inputLines
        persist()
        return words.count
    }
    private func prepareExternalImport(_ url: URL) {
        selectedTab = .account
        practiceSession = nil
        showBackup = false
        do {
            importStatus = "正在读取外部文件：\(url.lastPathComponent)"
            let text = try VocabularyImportReader.read(from: url)
            let count = try importText(VocabularyBackupCodec.normalized(text))
            importStatus = "最近导入成功：\(count) 个单词。"
            selectedTab = .records
            presentExternalImportResult("已自动导入，共恢复 \(count) 个单词及其记忆记录。")
        } catch {
            importStatus = "最近导入失败：\(error.localizedDescription)"
            presentExternalImportResult("无法导入这个文件：\(error.localizedDescription)")
        }
    }
    private func receivePendingExternalFile() {
        guard let file = VocabularyCheckExternalOpenBridge.takePendingFile() else { return }
        if let data = file.data {
            prepareExternalImport(data: data, filename: file.url.lastPathComponent)
        } else {
            prepareExternalImport(file.url)
        }
    }
    private func prepareExternalImport(data: Data, filename: String) {
        selectedTab = .account
        practiceSession = nil
        showBackup = false
        importStatus = "正在读取外部文件：\(filename)"
        do {
            let text = try VocabularyImportReader.decode(data)
            let count = try importText(VocabularyBackupCodec.normalized(text))
            importStatus = "最近导入成功：\(count) 个单词。"
            selectedTab = .records
            presentExternalImportResult("已自动导入，共恢复 \(count) 个单词及其记忆记录。")
        } catch {
            importStatus = "最近导入失败：\(error.localizedDescription)"
            presentExternalImportResult("无法导入这个文件：\(error.localizedDescription)")
        }
    }
    private func presentExternalImportResult(_ message: String) {
        externalImportMessage = message
        showExternalImportResult = true
    }
    private func persist() { if !NativeVocabularyStore.save(words: words, records: records, rounds: rounds) { showStorageError = true } }
    private func persistProgress() { if !NativeVocabularyStore.saveProgress(records: records, rounds: rounds) { showStorageError = true } }
}

private struct PracticeSession: Identifiable {
    let id = UUID()
    let wordIDs: [UUID]
    let modeKey: String
    let title: String
}

private struct PracticeHomeView: View {
    let words: [VocabularyWord]
    let records: [String: MemoryRecord]
    let rounds: [String: Int]
    let start: (PracticeMode) -> Void
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                Text("练习").font(.system(size: 36, weight: .bold, design: .rounded))
                VStack(alignment: .leading, spacing: 18) {
                    Label("已掌握 \(masteredCount) / \(words.count)", systemImage: "checkmark.seal").font(.subheadline.weight(.medium)).foregroundStyle(.secondary)
                    Text("开始今日学习").font(.system(size: 29, weight: .bold, design: .rounded))
                    ProgressView(value: Double(masteredCount), total: Double(max(words.count, 1))).tint(.primary)
                    HStack { Text("共 \(words.count) 个").foregroundStyle(.secondary); Spacer(); Button("开始") { start(.all) }.buttonStyle(.borderedProminent).disabled(words.isEmpty) }
                }.padding(22).background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                Text("快速开始").font(.title3.weight(.bold))
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                    modeButton(title: "没测过", icon: "circle", tint: .secondary, count: words.filter { (records[$0.word]?.total ?? 0) == 0 }.count, rounds: rounds["untested", default: 0]) { start(.untested) }
                    ForEach(MemoryCategory.allCases) { category in
                        modeButton(title: category.title, icon: category.icon, tint: category.tint, count: count(for: category), rounds: rounds[category.rawValue, default: 0]) { start(.category(category)) }
                    }
                }
                Text("检测概况").font(.title3.weight(.bold))
                HStack { summary(value: words.count, label: "总数"); summary(value: testedCount, label: "已检测"); summary(value: words.count - testedCount, label: "没测过") }
                    .padding(.vertical, 14).background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            }.padding(.horizontal, 18).padding(.top, 14).padding(.bottom, 18)
        }.scrollIndicators(.hidden)
    }
    private func count(for category: MemoryCategory) -> Int { words.filter { records[$0.word]?.lastCategory == category }.count }
    private var testedCount: Int { words.filter { (records[$0.word]?.total ?? 0) > 0 }.count }
    private var masteredCount: Int { words.filter { record in let value = records[record.word]; return (value?.counts[.instant, default: 0] ?? 0) >= 1 || (value?.counts[.know, default: 0] ?? 0) >= 2 }.count }
    private func modeButton(title: String, icon: String, tint: Color, count: Int, rounds: Int, action: @escaping () -> Void) -> some View {
        Button(action: action) { VStack(alignment: .leading, spacing: 12) { Image(systemName: icon).foregroundStyle(tint); Text(title).font(.headline); Text("\(count) 词 · \(rounds) 遍").font(.caption).foregroundStyle(.secondary) }.frame(maxWidth: .infinity, alignment: .leading).padding(14).background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous)) }.buttonStyle(.plain).disabled(count == 0)
    }
    private func summary(value: Int, label: String) -> some View { VStack(spacing: 4) { Text(String(value)).font(.title2.weight(.bold)).monospacedDigit(); Text(label).font(.caption).foregroundStyle(.secondary) }.frame(maxWidth: .infinity) }
}

private struct InputView: View {
    @Binding var inputText: String
    let savedCount: Int
    let save: () -> Void
    let start: () -> Void
    @FocusState private var inputFocused: Bool

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("录入单词").font(.system(size: 36, weight: .bold, design: .rounded))
                TextEditor(text: $inputText)
                    .focused($inputFocused)
                    .font(.system(.body, design: .monospaced))
                    .frame(minHeight: 260)
                    .padding(12)
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                Text("格式：单词//翻译//助记一|助记二|助记三\n保存录入内容时保留已有检测记录 · 已录入 \(savedCount) 个单词")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                HStack {
                    Button("保存单词") {
                        inputFocused = false
                        save()
                    }
                    .buttonStyle(.borderedProminent)
                    Button("直接开始检测") {
                        inputFocused = false
                        start()
                    }
                    .buttonStyle(.bordered)
                    .disabled(savedCount == 0)
                }
                Spacer(minLength: 80)
            }
            .padding(18)
            .contentShape(Rectangle())
            .onTapGesture { inputFocused = false }
        }
        .scrollIndicators(.hidden)
        .scrollDismissesKeyboard(.interactively)
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button("完成") { inputFocused = false }
            }
        }
    }
}

private struct RecordsView: View {
    let words: [VocabularyWord]
    let records: [String: MemoryRecord]
    let delete: (Set<UUID>) -> Void
    let clearRecords: () -> Void
    @State private var selected = Set<UUID>()
    @State private var sortDescending = false
    @State private var isSelecting = false
    @State private var showClearConfirmation = false
    private var sortedWords: [VocabularyWord] { words.sorted { lhs, rhs in let left = records[lhs.word]?.mastery ?? 0; let right = records[rhs.word]?.mastery ?? 0; return sortDescending ? left > right : left < right } }
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 18) {
            Text("记忆记录").font(.system(size: 36, weight: .bold, design: .rounded))
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 8) { ForEach(MemoryCategory.allCases) { category in VStack(spacing: 4) { Text(String(words.filter { records[$0.word]?.lastCategory == category }.count)).font(.title3.weight(.bold)); Text(category.title).font(.caption).foregroundStyle(.secondary) }.frame(maxWidth: .infinity).padding(.vertical, 10).background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16, style: .continuous)) } }
            HStack(spacing: 10) {
                Button(sortDescending ? "掌握度：高到低" : "掌握度：低到高") { sortDescending.toggle() }
                    .buttonStyle(.bordered)
                Spacer()
                Button(isSelecting ? "取消" : "批量选择") {
                    withAnimation(.easeInOut(duration: 0.18)) {
                        isSelecting.toggle()
                        if !isSelecting { selected.removeAll() }
                    }
                }
                .buttonStyle(.borderedProminent)
                Button(role: .destructive) { showClearConfirmation = true } label: { Image(systemName: "trash") }
                    .buttonStyle(.bordered)
            }
            if isSelecting {
                HStack(spacing: 10) {
                    Button(selected.count == words.count && !words.isEmpty ? "取消全选" : "全选") {
                        selected = selected.count == words.count ? [] : Set(words.map(\.id))
                    }
                    .buttonStyle(.bordered)
                    Spacer()
                    Text("已选择 \(selected.count) 个").font(.footnote).foregroundStyle(.secondary)
                    Button("删除选中") {
                        delete(selected)
                        selected.removeAll()
                        isSelecting = false
                    }
                    .disabled(selected.isEmpty)
                    .foregroundStyle(selected.isEmpty ? Color.secondary : Color.red)
                    .buttonStyle(.bordered)
                }
                .transition(.move(edge: .top).combined(with: .opacity))
            }
            ForEach(sortedWords) { word in
                Button {
                    guard isSelecting else { return }
                    if selected.contains(word.id) { selected.remove(word.id) } else { selected.insert(word.id) }
                } label: {
                    HStack(spacing: 12) {
                        if isSelecting {
                            Image(systemName: selected.contains(word.id) ? "checkmark.square.fill" : "square")
                                .font(.system(size: 22, weight: .medium))
                                .foregroundStyle(selected.contains(word.id) ? Color.accentColor : Color.secondary)
                                .transition(.scale.combined(with: .opacity))
                        }
                        VStack(alignment: .leading, spacing: 5) {
                            Text(word.word).font(.headline).foregroundStyle(.primary)
                            Text(word.translation).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
                        }
                        Spacer(minLength: 8)
                        if let category = records[word.word]?.lastCategory {
                            Text(category.title)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(category.tint)
                                .padding(.horizontal, 9)
                                .padding(.vertical, 6)
                                .background(category.tint.opacity(0.10), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                        }
                    }
                    .padding(14)
                    .contentShape(Rectangle())
                    .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .stroke(selected.contains(word.id) ? Color.accentColor.opacity(0.65) : Color.primary.opacity(0.12), lineWidth: selected.contains(word.id) ? 1.5 : 1)
                    }
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 80)
        }.padding(18) }.scrollIndicators(.hidden)
        .confirmationDialog("清空全部检测记录和完成遍数？单词与助记会保留。", isPresented: $showClearConfirmation, titleVisibility: .visible) {
            Button("清空记录", role: .destructive, action: clearRecords)
            Button("取消", role: .cancel) { }
        }
    }
}

private struct AccountView: View {
    let backgroundImage: UIImage?
    @Binding var backgroundTransparency: Double
    let setBackground: (Data) -> Void
    let removeBackground: () -> Void
    let makeExportText: () throws -> String
    let importText: (String) throws -> Int
    @Binding var importStatus: String
    let importCompleted: (Int) -> Void
    let restoreSnapshot: () throws -> Int
    let hasImportSnapshot: Bool
    let showBackup: () -> Void
    @Binding var practiceWordCardOpacity: Double
    @Binding var practiceTranslationOpacity: Double
    @Binding var practiceAnswerPanelOpacity: Double
    @Binding var practiceWordCardHeightRatio: Double
    @Binding var practiceAnswerPanelHeightRatio: Double
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var exportDocument = VocabularyTXTDocument()
    @State private var isExporting = false
    @State private var isImporting = false
    @State private var showRestoreConfirmation = false
    @State private var resultMessage = ""
    @State private var showResult = false

    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 18) {
            Text("账号").font(.system(size: 36, weight: .bold, design: .rounded))
            HStack { Image(systemName: "person.crop.circle.fill").font(.system(size: 44)); VStack(alignment: .leading) { Text("本机模式").font(.headline); Text("数据保存在本机，可通过 v2 TXT 跨设备传递").font(.caption).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "externaldrive.fill").foregroundStyle(.secondary) }.padding(18).background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            Text("自定义背景").font(.title3.weight(.bold))
            VStack(alignment: .leading, spacing: 14) {
                if let backgroundImage {
                    Image(uiImage: backgroundImage)
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: .infinity)
                        .frame(height: 150)
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                } else {
                    HStack(spacing: 10) {
                        Image(systemName: "photo")
                        Text("尚未选择背景图片")
                    }
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity)
                    .frame(height: 90)
                }

                PhotosPicker(selection: $selectedPhoto, matching: .images) {
                    Label(backgroundImage == nil ? "从相册选择图片" : "更换背景图片", systemImage: "photo.on.rectangle.angled")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                if backgroundImage != nil {
                    HStack {
                        Text("图片透明度")
                        Spacer()
                        Text("\(Int(backgroundTransparency * 100))%")
                            .monospacedDigit()
                            .foregroundStyle(.secondary)
                    }
                    Slider(value: $backgroundTransparency, in: 0...1)
                    Button(role: .destructive, action: removeBackground) {
                        Label("移除背景图片", systemImage: "trash")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
            }
            .padding(16)
            .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .onChange(of: selectedPhoto) { _, newPhoto in
                guard let newPhoto else { return }
                Task {
                    guard let data = try? await newPhoto.loadTransferable(type: Data.self) else { return }
                    await MainActor.run {
                        setBackground(data)
                        selectedPhoto = nil
                    }
                }
            }
            Text("检测页预览").font(.title3.weight(.bold))
            PracticeLayoutPreview(
                wordCardOpacity: $practiceWordCardOpacity,
                translationOpacity: $practiceTranslationOpacity,
                answerPanelOpacity: $practiceAnswerPanelOpacity,
                wordCardHeightRatio: $practiceWordCardHeightRatio,
                answerPanelHeightRatio: $practiceAnswerPanelHeightRatio
            )
            Text("账号与数据").font(.title3.weight(.bold))
            VStack(spacing: 10) {
                Button(action: showBackup) {
                    Label("备份概况", systemImage: "archivebox")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                }
                .buttonStyle(.bordered)

                Button {
                    do {
                        exportDocument = VocabularyTXTDocument(text: try makeExportText())
                        isExporting = true
                    } catch {
                        presentResult("导出失败：\(error.localizedDescription)")
                    }
                } label: {
                    Label("导出 App 数据 TXT", systemImage: "square.and.arrow.up")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                }
                .buttonStyle(.borderedProminent)

                Button { isImporting = true } label: {
                    Label("选择电脑或手机导出的 TXT", systemImage: "doc.badge.arrow.up")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                }
                .buttonStyle(.bordered)

                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: importStatus.contains("成功") ? "checkmark.circle.fill" : importStatus.contains("失败") ? "exclamationmark.triangle.fill" : "info.circle")
                        .foregroundStyle(importStatus.contains("成功") ? Color.green : importStatus.contains("失败") ? Color.orange : Color.secondary)
                    Text(importStatus)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(12)
                .background(Color(uiColor: .systemBackground), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                Button { showRestoreConfirmation = true } label: {
                    Label("恢复上一次导入前数据", systemImage: "arrow.uturn.backward.circle")
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(16)
                }
                .buttonStyle(.bordered)
                .disabled(!hasImportSnapshot)

            }
            Text("其他").font(.title3.weight(.bold)); HStack { Label("关于单词检测", systemImage: "info.circle"); Spacer(); Text(appVersion).foregroundStyle(.secondary) }.padding(16).background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 18, style: .continuous)); Spacer(minLength: 80)
        }.padding(18) }
        .scrollIndicators(.hidden)
        .fileExporter(
            isPresented: $isExporting,
            document: exportDocument,
            contentType: .plainText,
            defaultFilename: "VocabularyCheck-完整备份-v2.txt"
        ) { result in
            switch result {
            case .success(_):
                presentResult("TXT 数据已经导出完成。")
            case .failure(let error):
                presentResult("导出失败：\(error.localizedDescription)")
            }
        }
        .sheet(isPresented: $isImporting) {
            VocabularyDocumentPicker(
                onPick: { urls in
                    isImporting = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        importSelectedFiles(urls)
                    }
                },
                onCancel: { isImporting = false }
            )
            .ignoresSafeArea()
        }
        .confirmationDialog("恢复后会替换当前数据，是否继续？", isPresented: $showRestoreConfirmation, titleVisibility: .visible) {
            Button("恢复导入前数据", role: .destructive) {
                do {
                    let count = try restoreSnapshot()
                    presentResult("恢复完成，共恢复 \(count) 个单词及其记录。")
                } catch {
                    presentResult("恢复失败：\(error.localizedDescription)")
                }
            }
            Button("取消", role: .cancel) { }
        }
        .alert("数据处理", isPresented: $showResult) {
            Button("好", role: .cancel) { }
        } message: {
            Text(resultMessage)
        }
    }

    private func importSelectedFiles(_ urls: [URL]) {
        guard urls.count == 1, let url = urls.first else {
            importStatus = urls.isEmpty ? "没有选择文件。" : "导入失败：一次只能选择一个文件。"
            presentResult(importStatus)
            return
        }
        importStatus = "正在读取：\(url.lastPathComponent)"
        do {
            let text = try VocabularyImportReader.read(from: url)
            let count = try importText(VocabularyBackupCodec.normalized(text))
            importStatus = "最近导入成功：\(count) 个单词。"
            importCompleted(count)
        } catch {
            importStatus = "最近导入失败：\(error.localizedDescription)"
            presentResult("导入 TXT 失败：\(error.localizedDescription)")
        }
    }

    private func presentResult(_ message: String) {
        resultMessage = message
        showResult = true
    }

    private var appVersion: String {
        let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
        let build = Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—"
        return "\(version) (\(build))"
    }
}

private struct PracticeLayoutPreview: View {
    @Binding var wordCardOpacity: Double
    @Binding var translationOpacity: Double
    @Binding var answerPanelOpacity: Double
    @Binding var wordCardHeightRatio: Double
    @Binding var answerPanelHeightRatio: Double

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("这里的调整会直接应用到检测页。两个高度比例以检测页可用高度为基准，下面六个按钮会随面板高度自动缩放。")
                .font(.footnote)
                .foregroundStyle(.secondary)
            GeometryReader { proxy in
                let wordHeight = max(76, proxy.size.height * CGFloat(wordCardHeightRatio))
                let answerHeight = max(76, proxy.size.height * CGFloat(answerPanelHeightRatio))
                VStack(spacing: 8) {
                    Text("abandon").font(.headline)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .frame(height: wordHeight)
                        .background(Color(uiColor: .secondarySystemBackground).opacity(wordCardOpacity), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    Text("点击下方按钮显示翻译").font(.caption).foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity).frame(height: 34)
                        .background(Color(uiColor: .secondarySystemBackground).opacity(translationOpacity), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    VStack(spacing: 6) {
                        Text("检测结果").font(.caption.weight(.semibold))
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 6) {
                            ForEach(MemoryCategory.allCases) { category in
                                Text(category.title).font(.caption2.weight(.semibold))
                                    .frame(maxWidth: .infinity)
                                    .frame(height: max(24, (answerHeight - 34) / 2.4))
                                    .background(category.tint.opacity(0.16), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                            }
                        }
                    }
                    .padding(8)
                    .frame(maxWidth: .infinity)
                    .frame(height: answerHeight)
                    .background(Color(uiColor: .secondarySystemBackground).opacity(answerPanelOpacity), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
            }
            .frame(height: 260)

            PracticePreviewSlider(title: "单词/助记方框透明度", value: $wordCardOpacity)
            PracticePreviewSlider(title: "翻译方框透明度", value: $translationOpacity)
            PracticePreviewSlider(title: "检测结果方框透明度", value: $answerPanelOpacity)
            PracticePreviewSlider(title: "上方方框高度比例", value: $wordCardHeightRatio, range: 0.28...0.68)
            PracticePreviewSlider(title: "下方方框高度比例", value: $answerPanelHeightRatio, range: 0.18...0.42)
        }
        .padding(16)
        .background(Color(uiColor: .secondarySystemBackground), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

private struct PracticePreviewSlider: View {
    let title: String
    @Binding var value: Double
    var range: ClosedRange<Double> = 0.20...1.0

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(title).font(.footnote)
                Spacer()
                Text("\(Int(value * 100))%")
                    .font(.footnote.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
            Slider(value: $value, in: range)
        }
    }
}

private struct BackupView: View {
    let words: [VocabularyWord]
    let records: [String: MemoryRecord]
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack { VStack(spacing: 18) { Image(systemName: "archivebox").font(.system(size: 44)); Text("本机备份").font(.title2.weight(.bold)); Text("当前保存 \(words.count) 个单词和 \(records.count) 条记录").foregroundStyle(.secondary); Button("完成") { dismiss() }.buttonStyle(.borderedProminent) }.padding().navigationTitle("备份").navigationBarTitleDisplayMode(.inline) }
    }
}

private struct InlineMnemonicTextEditor: UIViewRepresentable {
    @Binding var text: String
    let selectAllOnAppear: Bool

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> UITextView {
        let view = UITextView()
        view.delegate = context.coordinator
        view.font = UIFont.preferredFont(forTextStyle: .body)
        view.backgroundColor = .clear
        view.isScrollEnabled = false
        view.textContainerInset = UIEdgeInsets(top: 3, left: 0, bottom: 3, right: 0)
        view.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        return view
    }

    func updateUIView(_ uiView: UITextView, context: Context) {
        if uiView.text != text { uiView.text = text }
        guard selectAllOnAppear, !context.coordinator.didSelectAll else { return }
        context.coordinator.didSelectAll = true
        DispatchQueue.main.async {
            uiView.becomeFirstResponder()
            uiView.selectAll(nil)
        }
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: InlineMnemonicTextEditor
        var didSelectAll = false

        init(_ parent: InlineMnemonicTextEditor) { self.parent = parent }

        func textViewDidChange(_ textView: UITextView) { parent.text = textView.text }
    }
}

private struct PracticeView: View {
    @Binding var words: [VocabularyWord]
    let queueIDs: [UUID]
    let backgroundImage: UIImage?
    let backgroundTransparency: Double
    let wordCardOpacity: Double
    let translationOpacity: Double
    let answerPanelOpacity: Double
    let wordCardHeightRatio: Double
    let answerPanelHeightRatio: Double
    @Binding var records: [String: MemoryRecord]
    @Binding var rounds: [String: Int]
    let modeKey: String
    let modeTitle: String
    let save: () -> Void
    let saveProgress: () -> Void
    let finish: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var index = 0
    @State private var showTranslation = false
    @State private var showMnemonic = false
    @State private var showAllMnemonics = false
    @State private var editingMnemonicID: String?
    @State private var editingMnemonicText = ""
    @FocusState private var inlineMnemonicFocused: Bool
    private var currentID: UUID { queueIDs[min(index, max(queueIDs.count - 1, 0))] }
    private var wordIndex: Int { words.firstIndex(where: { $0.id == currentID }) ?? 0 }
    private var word: VocabularyWord { words[wordIndex] }
    private var displayedMnemonics: [MnemonicItem] {
        let selected = word.mnemonics.filter(\.selected)
        return showAllMnemonics || selected.isEmpty ? word.mnemonics : selected
    }
    var body: some View {
        ZStack {
            Color(uiColor: .systemBackground).ignoresSafeArea()
            if let backgroundImage {
                GeometryReader { proxy in
                    Image(uiImage: backgroundImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(1 - backgroundTransparency)
                }
                .ignoresSafeArea()
            }
            GeometryReader { proxy in
            let usableHeight = max(proxy.size.height - 118, 300)
            let wordCardHeight = max(210, usableHeight * CGFloat(wordCardHeightRatio))
            let answerPanelHeight = max(150, usableHeight * CGFloat(answerPanelHeightRatio))
            VStack(spacing: 14) {
            HStack { Text("\(modeTitle) · 第 \(index + 1) / \(queueIDs.count) 个").font(.subheadline).foregroundStyle(.secondary); Spacer(); Button("结束检测") { finish(); dismiss() }.font(.headline) }
            ProgressView(value: Double(index), total: Double(max(queueIDs.count, 1))).tint(.primary)
            Group {
                if showMnemonic {
                    VStack(spacing: 10) {
                        ScrollView {
                            VStack(spacing: 10) {
                                if word.mnemonics.isEmpty {
                                    Text("该词暂无助记").foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(.vertical, 50)
                                } else {
                                    ForEach(displayedMnemonics) { item in
                                        mnemonicRow(item)
                                    }
                                    if !showAllMnemonics && !word.mnemonics.filter(\.selected).isEmpty && displayedMnemonics.count < word.mnemonics.count {
                                        Button("更多助记 ▾") { withAnimation { showAllMnemonics = true } }.buttonStyle(.bordered)
                                    } else if showAllMnemonics && !word.mnemonics.filter(\.selected).isEmpty {
                                        Button("仅显示已选") { withAnimation { showAllMnemonics = false } }.buttonStyle(.bordered)
                                    }
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.top, 16)
                        }
                        Button("返回单词") {
                            finishInlineMnemonicEdit()
                            withAnimation(.easeInOut(duration: 0.18)) { showMnemonic = false }
                        }
                        .buttonStyle(.borderedProminent)
                        Text("点击助剂项可修改内容。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.bottom, 8)
                    }
                } else {
                    Button {
                        showAllMnemonics = false
                        withAnimation(.easeInOut(duration: 0.18)) { showMnemonic = true }
                    } label: {
                        VStack(spacing: 14) {
                            Text(word.word).font(.system(size: 38, weight: .bold, design: .rounded)).foregroundStyle(.primary)
                            Text("点击单词卡片查看三条助记").font(.caption).foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .padding(24)
                    }
                    .buttonStyle(.plain)
                    .contentShape(Rectangle())
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: wordCardHeight)
            .background(Color(uiColor: .secondarySystemBackground).opacity(wordCardOpacity), in: RoundedRectangle(cornerRadius: 30, style: .continuous))

            Group {
                if showTranslation {
                    VStack(spacing: 8) {
                        Text(word.translation.isEmpty ? "（未录入翻译）" : word.translation).font(.title3.weight(.semibold)).multilineTextAlignment(.center)
                        if !word.example.isEmpty { Text(word.example).font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center) }
                    }
                    .frame(maxWidth: .infinity).padding(14)
                    .background(Color(uiColor: .secondarySystemBackground).opacity(translationOpacity), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                } else {
                    Text("点击下方按钮显示翻译").font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity).padding(14)
                }
            }
            VStack(spacing: 8) {
                Button("显示翻译") { showTranslation = true }
                .buttonStyle(.borderedProminent)
                .frame(maxWidth: .infinity)
                .frame(height: 46)
                .disabled(showTranslation)

                GeometryReader { panelProxy in
                    let gridHeight = max(90, panelProxy.size.height - 54)
                    let buttonHeight = max(38, (gridHeight - 8) / 2)
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 8) {
                        ForEach(MemoryCategory.allCases) { category in
                            judgeButton(category, height: buttonHeight)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: gridHeight)
                }
            }
            .padding(10)
            .frame(height: answerPanelHeight)
            .background(Color(uiColor: .secondarySystemBackground).opacity(answerPanelOpacity), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            }
            .padding(.horizontal, 18)
            .padding(.top, 20)
            .padding(.bottom, 12)
            }
        }
        .interactiveDismissDisabled()
    }
    private func answer(_ category: MemoryCategory) {
        var record = records[word.word] ?? MemoryRecord()
        record.counts[category, default: 0] += 1
        record.lastCategory = category
        record.lastTestedAt = Date()
        records[word.word] = record
        if index + 1 >= queueIDs.count {
            rounds[modeKey, default: 0] += 1
            saveProgress()
            finish()
            dismiss()
        } else {
            index += 1
            showTranslation = false
            showMnemonic = false
            showAllMnemonics = false
            saveProgress()
        }
    }
    @ViewBuilder
    private func judgeButton(_ category: MemoryCategory, height: CGFloat) -> some View {
        if #available(iOS 26.0, *) {
            Button { answer(category) } label: { judgeLabel(category, height: height) }
                .buttonStyle(.glass)
                .buttonBorderShape(.roundedRectangle(radius: 17))
        } else {
            Button { answer(category) } label: { judgeLabel(category, height: height) }
                .buttonStyle(.bordered)
        }
    }
    private func judgeLabel(_ category: MemoryCategory, height: CGFloat) -> some View {
        VStack(spacing: 5) {
            Circle().fill(category.tint).frame(width: 7, height: 7)
            Text(category.title).font(.caption.weight(.semibold))
        }
        .frame(maxWidth: .infinity)
        .frame(height: height)
    }
    @ViewBuilder
    private func mnemonicRow(_ item: MnemonicItem) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Button { toggleSelection(item.id) } label: {
                Image(systemName: item.selected ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(item.selected ? Color.accentColor : Color.secondary)
                    .frame(width: 24, height: 28)
            }
            .buttonStyle(.plain)

            if editingMnemonicID == item.id {
                InlineMnemonicTextEditor(text: $editingMnemonicText, selectAllOnAppear: true)
                    .frame(minHeight: 44)
                    .padding(.horizontal, 8)
                    .background(Color.accentColor.opacity(0.14), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                Button("完成") { finishInlineMnemonicEdit() }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.accentColor)
                    .frame(minWidth: 44)
            } else {
                Button {
                    beginInlineMnemonicEdit(item)
                } label: {
                    Text(cleanMnemonic(item.text))
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.leading)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(12)
        .background(Color(uiColor: .systemBackground).opacity(0.75), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .contentShape(Rectangle())
    }
    private func toggleSelection(_ id: String) {
        guard let itemIndex = words[wordIndex].mnemonics.firstIndex(where: { $0.id == id }) else { return }
        words[wordIndex].mnemonics[itemIndex].selected.toggle()
        save()
    }
    private func beginInlineMnemonicEdit(_ item: MnemonicItem) {
        editingMnemonicID = item.id
        editingMnemonicText = item.text
        inlineMnemonicFocused = true
    }
    private func finishInlineMnemonicEdit() {
        inlineMnemonicFocused = false
        commitMnemonicEdit()
        editingMnemonicID = nil
    }
    private func commitMnemonicEdit() {
        guard let editingMnemonicID, let itemIndex = words[wordIndex].mnemonics.firstIndex(where: { $0.id == editingMnemonicID }) else { return }
        let cleanText = editingMnemonicText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanText.isEmpty else { return }
        words[wordIndex].mnemonics[itemIndex].text = cleanText
        save()
    }
    private func cleanMnemonic(_ value: String) -> String { let cleaned = value.replacingOccurrences(of: #"^\s*联想[：:]\s*"#, with: "", options: .regularExpression); return cleaned.isEmpty ? "暂无助记" : cleaned }
}

#Preview { ContentView() }
